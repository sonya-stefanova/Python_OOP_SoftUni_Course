from project.decoration.ornament import Ornament
from project.decoration.plant import Plant


class DecorationFactory:
    DECORATION_TYPES = {
        'Plant': Plant,
        'Ornament': Ornament
    }

    def create_decoration(self, decoration_type: str):
        if decoration_type not in self.DECORATION_TYPES:
            raise ValueError('Invalid decoration type.')
        return self.DECORATION_TYPES[decoration_type]()