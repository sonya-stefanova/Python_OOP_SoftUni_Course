from project.aquarium.freshwater_aquarium import FreshwaterAquarium
from project.aquarium.saltwater_aquarium import SaltwaterAquarium


class AquariumFactory:
    AQUARIUM_TYPES = {
        'FreshwaterAquarium': FreshwaterAquarium,
        'SaltwaterAquarium': SaltwaterAquarium
    }

    def create_aquarium(self, aquarium_type: str, aquarium_name: str):
        if aquarium_type not in self.AQUARIUM_TYPES:
            raise ValueError('Invalid aquarium type.')
        return self.AQUARIUM_TYPES[aquarium_type](aquarium_name)