from project.aquarium.base_aquarium import BaseAquarium
from project.fish.freshwater_fish import FreshwaterFish


class FreshwaterAquarium(BaseAquarium):
    CAPACITY = 50

    def __init__(self, name: str):
        super().__init__(name, self.CAPACITY)

    @property
    def fish_type(self):
        return FreshwaterFish.__name__