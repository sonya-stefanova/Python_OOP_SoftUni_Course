from project.aquarium.freshwater_aquarium import FreshwaterAquarium
from project.aquarium.saltwater_aquarium import SaltwaterAquarium
from project.decoration.decoration_repository import DecorationRepository
from project.decoration.ornament import Ornament
from project.decoration.plant import Plant
from project.factories.aquarium_factory import AquariumFactory
from project.factories.decoration_factory import DecorationFactory
from project.factories.fish_factory import FishFactory
from project.fish.freshwater_fish import FreshwaterFish
from project.fish.saltwater_fish import SaltwaterFish

class Controller:
    def __init__(self):
        self.decorations_repository = DecorationRepository()  #[]
        self.aquariums = []

        self.aquarium_factory = AquariumFactory()
        self.fish_factory = FishFactory()
        self.decoration_factory = DecorationFactory()


    def __find_aquarium_by_name(self, aquarium_name):
        aquarium = next(filter(lambda a: a.name == aquarium_name, self.aquariums), None)
        return aquarium

    def add_aquarium(self, aquarium_type: str, aquarium_name: str):
        """Creates an aquarium of the given type and then adds it to the list of aquariums.
        Valid types are: "FreshwaterAquarium" and "SaltwaterAquarium".
        If the aquarium type is invalid, you should return the following message:
        •	"Invalid aquarium type."
        If the Aquarium is added successfully, the method should return the following message:
        •	"Successfully added {aquarium_type}."
"""
        try:
            aquarium = self.aquarium_factory.create_aquarium(aquarium_type, aquarium_name)
            self.aquariums.append(aquarium)
            return f'Successfully added {aquarium_type}.'
        except ValueError as error:
            return str(error)


    def add_decoration(self, decoration_type: str):
        """Creates a decoration of the given type and adds it to the DecorationRepository.
            If the decoration type is invalid, return the following message:
            •	"Invalid decoration type."
            The method should return the following string if the operation is successful:
            •	"Successfully added {decoration_type}."
            """
        try:
            decoration = self.decoration_factory.create_decoration(decoration_type)
            self.decorations_repository.add(decoration)
            return f"Successfully added {decoration_type}."
        except ValueError as error:
            return str(error)


    def insert_decoration(self, aquarium_name: str, decoration_type: str):
        """If there is such decoration and such aquarium,
        -->you should add the first occurrence of the desired decoration to the aquarium with the given name.
         -->You should remove the decoration from the DecorationRepository and return the following message:
        •	"Successfully added {decoration_type} to {aquarium_name}."
        If there is no such decoration, you should return the following message:
        •	"There isn't a decoration of type {decoration_type}."
"""
        decoration = self.decorations_repository.find_by_type(decoration_type)

        if decoration == "None":
            return f"There isn't a decoration of type {decoration_type}."

        aquarium = self.__find_aquarium_by_name(aquarium_name)
        aquarium.add_decoration(decoration)
        self.decorations_repository.remove(decoration)
        return f"Successfully added {decoration_type} to {aquarium_name}."



    def add_fish(self, aquarium_name: str, fish_type: str, fish_name: str, fish_species: str, price: float):
        """Creates a fish of the given type and adds it to the aquarium with the given name.
         If the fish type is invalid, you should return a massage:
        •	"There isn't a fish of type {fish_type}."
        If the fish type is valid, return one of the following strings:
        •	"Not enough capacity." - if there is not enough capacity to add the fish in the aquarium.
        •	"Water not suitable." - if the fish cannot live in the aquarium.
        •	"Successfully added {fish_type} to {aquarium_name}." - if the fish is added successfully in the aquarium.
        You can use the overridden add_fish Aquarium method
"""
        try:
            fish = self.fish_factory.create_fish(fish_type, fish_name, fish_species, price)
            aquarium = self.__find_aquarium_by_name(aquarium_name)
            return aquarium.add_fish(fish)
        except ValueError as error:
            return str(error)


    def feed_fish(self, aquarium_name: str):
        """Feeds all fish in the aquarium with the given name.
        Returns a string with information about how many fish were successfully fed, in the following format:
        •	"Fish fed: {fed_count}"
"""
        aquarium = self.__find_aquarium_by_name(aquarium_name)
        aquarium.feed()
        fed_fish_count = len(aquarium.fish)
        return f"Fish fed: {fed_fish_count}"

    def calculate_value(self, aquarium_name: str):
        """Calculates the value of the aquarium with the given name.
        It is calculated by the sum of all fish’s and decorations’ prices in the aquarium.
        Return a string in the following format:
        •	"The value of Aquarium {aquarium_name} is {value}."
        o	The value should be formatted to the 2nd decimal place!
        """
        aquarium = self.__find_aquarium_by_name(aquarium_name)
        total = sum(d.price for d in aquarium.decorations) + sum(f.price for f in aquarium.fish)
        return f"The value of Aquarium {aquarium_name} is {total:.2f}."

    def report(self):
        for aquarium in self.aquariums:
            return str(aquarium)

