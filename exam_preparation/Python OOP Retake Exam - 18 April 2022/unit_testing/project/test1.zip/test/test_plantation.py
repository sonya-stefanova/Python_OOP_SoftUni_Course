from project.plantation import Plantation
from unittest import TestCase


class TestPlantation(TestCase):
    def setUp(self):
        self.plantation = Plantation(2)

    def test_plantation_init(self):
        self.assertEqual(2, self.plantation.size)
        self.assertEqual({}, self.plantation.plants)
        self.assertEqual([], self.plantation.workers)

    def test_setter_raise_ValueError(self):
        with self.assertRaises(ValueError) as error:
            self.plantation.size = -1

        self.assertEqual("Size must be positive number!", str(error.exception))

    def test_hire_worker_raise_ValueError(self):
        employee = "Ivan"
        self.plantation.workers.append(employee)
        with self.assertRaises(ValueError) as error:
            self.plantation.hire_worker(employee)
        self.assertEqual("Worker already hired!", str(error.exception))
        self.assertEqual(1, len(self.plantation.workers))

    def test_hire_worker_correct_returns_string(self):
        employee = "Sonya"
        self.assertEqual(f"{employee} successfully hired.", self.plantation.hire_worker(employee))
        self.assertEqual(1, len(self.plantation.workers))
        self.assertIn("Sonya", self.plantation.workers)

    def test_len_return_count_of_plants(self):
        self.plantation.plants = {
            "Sonya": ["plant1", "plant2", "plant3"],
            "Lolu": ["plant4", "plant5", "plant6"]
        }
        result = len(self.plantation)
        self.assertEqual(6, len(self.plantation))

    def test_planting_raises_if_worker_not_in_workers(self):
        self.plantation.hire_worker('Sonya')
        with self.assertRaises(ValueError) as error:
            self.plantation.hire_worker('Sonya')
        self.assertEqual(str(error.exception), 'Worker already hired!')

    def test_planting_raises_size_error(self):
        self.plantation.size = 1
        self.plantation.hire_worker('Sonya')
        self.plantation.planting('Sonya', 'roses')
        with self.assertRaises(ValueError) as error:
            self.plantation.planting('Sonya', "Water Lillies")
        self.assertEqual("The plantation is full!", str(error.exception))

    def test_planting_return_when_worker_already_added(self):
        self.plantation.hire_worker('Sonya')
        self.plantation.planting('Sonya', 'roses')
        self.assertEqual('Sonya planted strawberries.', self.plantation.planting('Sonya', 'strawberries'))

    def test_planting_return_first_dict_assignment(self):
        self.plantation.hire_worker('Sonya')
        result = self.plantation.planting('Sonya', "strawberries")
        self.assertEqual('Sonya planted it\'s first strawberries.', result)
        self.assertEqual(1, len(self.plantation.plants["Sonya"]))

    def test_str_representation_correctness(self):
        self.plantation.size = 6
        self.plantation.plants = {
            "Sonya": ["roses", "lillies"],
            "Plamen": ["roses", "lillies", "carrots"]
        }
        result = str(self.plantation)
        expected = f"Plantation size: 6\n\n"
        expected += f"Sonya planted: roses, lillies\n"
        expected += f"Plamen planted: roses, lillies, carrots"

        self.assertEqual(expected, result)

    def test_repr_correctness(self):

        self.plantation.hire_worker("Sonya")
        self.plantation.hire_worker("Plamen")
        result = repr(self.plantation)
        expected = f"Size: 2\nWorkers: Sonya, Plamen"
        self.assertEqual(expected, result)